import { buscarPokemons } from "./api.js";
import { mostrarPokemons } from "./ui.js";
import { iniciarPesquisa } from "./search.js";

async function iniciar() {

    const pokemons = await buscarPokemons();

    mostrarPokemons(pokemons);

    iniciarPesquisa(pokemons);

}

iniciar();