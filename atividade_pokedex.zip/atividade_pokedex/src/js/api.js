const URL = "https://pokeapi.co/api/v2/pokemon?limit=125";

export async function buscarPokemons() {
    try {
        const resposta = await fetch(URL);

        if (!resposta.ok) {
            throw new Error("Erro ao buscar os Pokémon.");
        }

        const dados = await resposta.json();

        return dados.results;
    } catch (erro) {
        console.error(erro);
        return [];
    }
}