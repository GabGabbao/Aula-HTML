import { mostrarPokemons } from "./ui.js";

export function iniciarPesquisa(listaPokemon) {

    const campoPesquisa = document.getElementById("search");

    campoPesquisa.addEventListener("input", () => {

        const pesquisa = campoPesquisa.value.toLowerCase().trim();

        const pokemonFiltrados = listaPokemon.filter((pokemon) => {

            const id = pokemon.url.split("/")[6];

            return (
                pokemon.name.includes(pesquisa) ||
                id === pesquisa
            );

        });

        mostrarPokemons(pokemonFiltrados);

    });

}