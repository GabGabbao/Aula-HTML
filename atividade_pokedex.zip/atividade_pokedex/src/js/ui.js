export function mostrarPokemons(lista) {

    const pokemonList = document.getElementById("pokemon-list");

    pokemonList.innerHTML = "";

    lista.forEach((pokemon) => {

        // Pega o número da URL
        const id = pokemon.url.split("/")[6];

        // Monta a URL da imagem
        const imagem = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${id}.png`;

        pokemonList.innerHTML += `
            <div class="card">
                <img src="${imagem}" alt="${pokemon.name}">
                <p>#${id}</p>
                <h3>${pokemon.name.charAt(0).toUpperCase() + pokemon.name.slice(1)}</h3>
            </div>
        `;

    });

}